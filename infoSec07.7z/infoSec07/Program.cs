﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;


namespace infoSec07
{
    class Program
    {
        static void Main(string[] args)
        {
            Users user;               
            Console.WriteLine("1-Creat\n2-Load");
            string choice = Console.ReadLine();
            if (choice.Equals("1"))
            {
                Console.WriteLine("Name");
                string name = Console.ReadLine();
                Console.WriteLine("Amount");
                double intitial = Convert.ToDouble(Console.ReadLine());
                user = new Users(intitial);
                string text = user.toString();
                using (System.IO.StreamWriter file =
                    new System.IO.StreamWriter(@"C:\Users\Bauyrzhan\Desktop\test\" + name + ".txt", true))
                {
                    file.WriteLine(text);
                }
                for (int i = 0; i < 3; i++)
                {
                    Console.WriteLine("Deposit amount");
                    double amount = Convert.ToDouble(Console.ReadLine());
                    user.deposit(amount);
                    text = user.toString();
                    using (System.IO.StreamWriter file =
                    new System.IO.StreamWriter(@"C:\Users\Bauyrzhan\Desktop\test\" + name + ".txt", true))
                    {
                        file.WriteLine(text);
                    }
                }
            }
            else if (choice.Equals("2"))
            {
                Console.WriteLine("Enter name");
                string name=Console.ReadLine();
                string path=@"C:\Users\Bauyrzhan\Desktop\test\" + name + ".txt";
                if(File.Exists(path)){
                    if (validate(name))
                    {
                        Console.WriteLine("valid");
                        
                    }
                    else
                    {
                        Console.WriteLine("Not valid");
                    }
                }
                else
                {
                    Console.WriteLine("Not such user");
                }                       
            }
        }

        private static Boolean validate(String name)
        {
            bool a = true;
            string path = @"C:\Users\Bauyrzhan\Desktop\test\" + name + ".txt";
            string[] lines = System.IO.File.ReadAllLines(path);
            int count = 0;
            foreach (string line in lines)
            {
                count++;
            }
            
            for (int j = count - 1; j >= 1; j--)
            {
                if (lines[j].Split(',')[1]!=toHashString(lines[j - 1]))
                {                    
                    a = false;
                }
            }

            return a;            
        }

        private static  string toHashString(string hashh)
        {
            string text = hashh;
            byte[] bytes = Encoding.Unicode.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            byte[] hash = hashstring.ComputeHash(bytes);
            string hashString = string.Empty;
            foreach (byte x in hash)
            {
                hashString += String.Format("{0:x2}", x);
            }
            return hashString;
        }
    }
}
