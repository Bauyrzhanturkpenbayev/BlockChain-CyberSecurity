﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace infoSec07
{
    class Users
    {
        
        private double amount;
        public string hash;
        public Users(double amount)
        {
            
            this.amount = amount;
            this.hash = "0";
        }
        public string toString()
        {
            string result=amount+","+hash;
            return result;
        }
        public void deposit(double a)
        {
            string text = toString();
            hash = toHashString(text);    
            amount += a;
                   
        }
        private string toHashString(string str)
        {
            string text = str;
            byte[] bytes = Encoding.Unicode.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            byte[] hash = hashstring.ComputeHash(bytes);
            string hashString = string.Empty;
            foreach (byte x in hash)
            {
                hashString += String.Format("{0:x2}", x);
            }
            return hashString;
        }
        
    }
}
